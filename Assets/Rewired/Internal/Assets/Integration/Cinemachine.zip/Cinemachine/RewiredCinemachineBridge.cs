﻿// Copyright (c) 2018 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

namespace Rewired.Integration.Cinemachine {
    using UnityEngine;

    /// <summary>
    /// Changes input source for Cinemachine to Rewired.
    /// You do not need to add this Component to a GameObject in order for it to work,
    /// but you can do so if you want to be able to set the Player Id in the inspector.
    /// Otherwise, you can change the Player Id through the static playerId property.
    /// </summary>
    public sealed class RewiredCinemachineBridge : MonoBehaviour {

        // Instance Members

        [Tooltip("The Player Id of the Player that controls Cinemachine input.")]
        [SerializeField]
        private int _playerId = 0;

        [Tooltip("The absolute sensitivity multipler. This is only applied to absolute axis sources (joystick axes, keyboard keys, etc.).")]
        [SerializeField]
        [Rewired.Utils.Attributes.FieldRange(0f, float.MaxValue)]
        private float _absoluteAxisSensitivity = defaultabsoluteAxisSensitivity;
        
        [Tooltip("If enabled, input values from absolute axis sources will be scaled based on the screen resolution. This makes joystick axes behave more consistently with mouse axes at different screen resolutions.")]
        [SerializeField]
        private bool _scaleAbsoluteAxesToScreen = s_scaleAbsoluteAxesToScreen;

        private void Awake() {
            s_instance = this;
            s_playerId = _playerId;
            s_absoluteAxisSensitivity = _absoluteAxisSensitivity;
        }

#if UNITY_EDITOR
        private void OnValidate() {
            if(s_playerId != _playerId) {
                s_playerId = _playerId;
            }
            if(s_absoluteAxisSensitivity != _absoluteAxisSensitivity) {
                s_absoluteAxisSensitivity = _absoluteAxisSensitivity;
            }
        }
#endif

        private void OnDestroy() {
            if(s_instance == this) s_instance = null;
        }

        // Static Members

        /// <summary>
        /// The default absolute source sensitivity.
        /// </summary>
        public const float defaultabsoluteAxisSensitivity = 30f;

        private static RewiredCinemachineBridge s_instance;
        private static int s_playerId = 0;
        private static float s_absoluteAxisSensitivity = defaultabsoluteAxisSensitivity;
        private static bool s_scaleAbsoluteAxesToScreen = false;

        /// <summary>
        /// The Player Id of the Player that controls Cinemachine input.
        /// </summary>
        public static int playerId {
            get { return s_playerId; }
            set {
                s_playerId = value;
                if(s_instance != null) s_instance._playerId = value;
            }
        }

        /// <summary>
        /// The absolute sensitivity multipler. This is only applied to absolute axis sources (joystick axes, keyboard keys, etc.).
        /// </summary>
        public static float absoluteAxisSensitivity { 
            get { return s_absoluteAxisSensitivity; } 
            set {
                if(value < 0f) value = 0f;
                s_absoluteAxisSensitivity = value;
                if(s_instance != null) s_instance._absoluteAxisSensitivity = value;
            }
        }
        
        /// <summary>
        /// If enabled, input values from absolute axis sources will be scaled based on the screen resolution.
        /// This makes joystick axes behave more consistently with mouse axes at different screen resolutions.
        /// </summary>
        public static bool scaleAbsoluteAxesToScreen {
            get { return s_scaleAbsoluteAxesToScreen; } 
            set {
                s_scaleAbsoluteAxesToScreen = value;
                if(s_instance != null) s_instance._scaleAbsoluteAxesToScreen = value;
            }
        }

        [RuntimeInitializeOnLoadMethod]
        private static void Initialize() {
            global::Cinemachine.CinemachineCore.GetInputAxis = GetAxis;
        }

        private static float GetAxis(string name) {
            if (!ReInput.isReady) return UnityEngine.Input.GetAxis(name);
            Player player = ReInput.players.GetPlayer(playerId);
            if(player == null) return 0f;
            float value = player.GetAxis(name);
            if(value != 0f && player.GetAxisCoordinateMode(name) == AxisCoordinateMode.Absolute) {
                value *= s_absoluteAxisSensitivity * Time.unscaledDeltaTime;
                if(s_scaleAbsoluteAxesToScreen) value *= Screen.currentResolution.width / 1920f;
            }
            return value;
        }
    }
}